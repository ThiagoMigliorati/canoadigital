'use strict';

const Employee = require('../models/employee.model');

exports.findAll = function(req, res) {
  Employee.findAll(function(err, employee) {
    console.log('controller all')
    if (err)
    res.send(err);
    //console.log('res', employee);
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.header(
        "Access-Control-Allow-Headers",
        "Origin, X-Requested-With, Content-Type, Accept"
    );
    res.json(employee);
  });
};

exports.create = function(req, res) {
    const new_employee = new Employee(req.body);

    //handles null error 
   if(req.body.constructor === Object && Object.keys(req.body).length === 0){
        res.status(400).send({ error:true, message: 'Please provide all required field' });
    }else{
        Employee.create(new_employee, function(err, employee) {
            if (err)
            res.send(err);
            res.json({error:false,message:"Employee added successfully!",data:employee});
        });
    }
};

exports.findById = function(req, res) {
    console.log('get id')
    console.log(req.params)
    Employee.findById(req.params.id, function(err, employee) {
        if (err)
        res.send(err);
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.header(
            "Access-Control-Allow-Headers",
            "Origin, X-Requested-With, Content-Type, Accept"
        );
        console.log(employee)
        res.json(employee);
    });
};

exports.update = function(req, res) {
    console.log(req.body)
    if(req.body.constructor === Object && Object.keys(req.body).length === 0){
        res.status(400).send({ error:true, message: 'Please provide all required field' });
    }else{
        Employee.update(req.params.id, new Employee(req.body), function(err, employee) {
            if (err)
            res.send(err);
            res.json({ error:false, message: 'Employee successfully updated' });
        });
    }
};


exports.delete = function(req, res) {
  Employee.delete( req.params.id, function(err, employee) {
    if (err)
    res.send(err);
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.header(
        "Access-Control-Allow-Headers",
        "Origin, X-Requested-With, Content-Type, Accept"
    );
    res.json({ error:false, message: 'Employee successfully deleted' });
  });
};