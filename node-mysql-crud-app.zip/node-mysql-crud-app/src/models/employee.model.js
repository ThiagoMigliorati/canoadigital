'user strict';
var dbConn = require('./../../config/db.config');

//Employee object create
var Employee = function(employee){
    this.veiculo     = employee.veiculo;
    this.marca       = employee.marca;
    this.ano         = employee.ano;
    this.descricao   = employee.descricao;
    this.vendido     = employee.vendido;
    this.created_at  = new Date();
    this.updated_at  = new Date();
};
Employee.create = function (newEmp, result) {    
    dbConn.query("INSERT INTO veiculos set ?", newEmp, function (err, res) {
        if(err) {
            console.log("error: ", err);
            result(err, null);
        }
        else{
            console.log(res.insertId);
            result(null, res.insertId);
        }
    });           
};
Employee.findById = function (id, result) {
    dbConn.query("Select * from veiculos where id = ? ", id, function (err, res) {             
        if(err) {
            console.log("error: ", err);
            result(err, null);
        }
        else{
            result(null, res);
        }
    });   
};
Employee.findAll = function (result) {
    dbConn.query("Select * from veiculos", function (err, res) {
        if(err) {
            console.log("error: ", err);
            result(null, err);
        }
        else{
            console.log('veiculos : ', res);  
            result(null, res);
        }
    });   
};
Employee.update = function(id, employee, result){
    console.log(id)
    console.log(employee)
  dbConn.query("UPDATE veiculos SET veiculo=?,marca=?,ano=?,descricao=?,vendido=? WHERE id = ?", [employee.veiculo,employee.marca,employee.ano,employee.descricao,employee.vendido, id], function (err, res) {
        if(err) {
            console.log("error: ", err);
            result(null, err);
        }else{   
            result(null, res);
        }
    }); 
};
Employee.delete = function(id, result){
    console.log('delete')
     dbConn.query("DELETE FROM veiculos WHERE id = ?", [id], function (err, res) {
        if(err) {
            console.log("error: ", err);
            result(null, err);
        }
        else{
            result(null, res);
        }
    }); 
};

module.exports= Employee;